from project.hardware.heavy_hardware import HeavyHardware
from project.hardware.power_hardware import PowerHardware


class System:
    _hardware = []
    _software = []

    @staticmethod
    def register_power_hardware(name, capacity, memory):
        System._hardware.append(PowerHardware(name, capacity, memory))

    @staticmethod
    def register_heavy_hardware(name, capacity, memory):
        System._hardware.append(HeavyHardware(name, capacity, memory))

    @staticmethod
    def register_express_software(hardware_name, name, capacity_consumption, memory_consumption):
        pass

    @staticmethod
    def register_light_software(hardware_name, name, capacity_consumption, memory_consumption):
        pass

    @staticmethod
    def release_software_component(hardware_name, software_name):
        pass

    @staticmethod
    def analyze():
        pass

    @staticmethod
    def system_split():
        pass


sys = System()
sys.register_power_hardware('komp',2,3)


print(sys._hardware)